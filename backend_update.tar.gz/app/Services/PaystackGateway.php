<?php

namespace App\Services;

use App\Models\Applicant;
use App\Models\Payment;
use App\Services\Contracts\PaymentGatewayInterface;
use App\Support\Audit;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * Paystack integration. A payment is only ever marked SUCCESS after the
 * backend itself confirms it with Paystack (verify API or signed webhook),
 * and only if the amount and currency match what we asked for.
 */
class PaystackGateway implements PaymentGatewayInterface
{
    public function __construct(private NumberGenerator $numbers) {}

    /**
     * Simulated payments: development only, and only while no Paystack
     * secret key is configured. As soon as PAYSTACK_SECRET_KEY is set, real
     * Paystack checkout is used (test keys sk_test_... in development).
     */
    public function isFake(): bool
    {
        if ((bool) config('nis.paystack.fake')) {
            return true;
        }

        return ! app()->isProduction() && blank(config('nis.paystack.secret_key'));
    }

    /**
     * Receipt details for slips: never the reusable authorization code.
     *
     * @return array{date: ?string, gateway: string, mode: ?string, gateway_reference: ?string, pan: ?string}
     */
    public static function receipt(Payment $payment): array
    {
        $data = $payment->gateway_response ?? [];
        $auth = $data['authorization'] ?? [];
        $pan = isset($auth['last4']) ? ($auth['bin'] ?? '').'XXXXXX'.$auth['last4'] : null;

        return [
            'date' => $payment->paid_at?->toIso8601String(),
            'gateway' => $payment->channel === 'fake' ? 'Paystack (test simulation)' : 'Paystack',
            'mode' => match ($payment->channel) {
                null => null,
                'fake' => 'Test simulation',
                default => ucwords(str_replace('_', ' ', $payment->channel)),
            },
            'gateway_reference' => isset($data['id']) ? (string) $data['id'] : null,
            'pan' => $pan,
        ];
    }

    /**
     * @return array{payment: Payment, authorization_url: ?string, access_code: ?string, public_key: ?string, rrr: ?string, gateway: string, fake: bool}
     */
    public function initialize(Applicant $applicant, int $amountKobo, string $callbackUrl): array
    {
        $payment = Payment::create([
            'applicant_id' => $applicant->id,
            'provider' => 'PAYSTACK',
            'reference' => $this->numbers->paymentReference(),
            'amount_kobo' => $amountKobo,
            'currency' => 'NGN',
            'status' => 'INITIALIZED',
        ]);

        if ($this->isFake()) {
            return [
                'payment' => $payment,
                'authorization_url' => null,
                'access_code' => null,
                'public_key' => null,
                'rrr' => null,
                'gateway' => 'paystack',
                'fake' => true,
            ];
        }

        try {
            $client = $this->client();
            $httpResponse = $client->post('/transaction/initialize', [
                'email' => $applicant->email,
                'amount' => $amountKobo,
                'currency' => 'NGN',
                'reference' => $payment->reference,
                'callback_url' => $callbackUrl,
                'metadata' => ['applicant_id' => $applicant->id, 'purpose' => 'RESIDENCE_CARD_FEE'],
            ]);

            if ($httpResponse->failed()) {
                $err = $httpResponse->json('message') ?? ('Paystack initialization failed (HTTP '.$httpResponse->status().')');
                Log::error('Paystack initialization HTTP failure', [
                    'status' => $httpResponse->status(),
                    'body' => $httpResponse->body(),
                    'reference' => $payment->reference,
                ]);
                throw new RuntimeException("Paystack error: {$err}");
            }

            $response = $httpResponse->json('data') ?? [];
        } catch (Throwable $e) {
            if ($e instanceof RuntimeException) {
                throw $e;
            }
            Log::error('Paystack connection exception', [
                'error' => $e->getMessage(),
                'reference' => $payment->reference,
            ]);
            throw new RuntimeException('Unable to reach Paystack payment gateway: '.$e->getMessage(), 0, $e);
        }

        return [
            'payment' => $payment,
            'authorization_url' => $response['authorization_url'] ?? null,
            'access_code' => $response['access_code'] ?? null,
            'public_key' => config('nis.paystack.public_key'),
            'rrr' => null,
            'gateway' => 'paystack',
            'fake' => false,
        ];
    }

    /**
     * Confirm the payment with Paystack and record the outcome.
     */
    public function verify(Payment $payment): Payment
    {
        if ($payment->isSuccessful()) {
            return $payment;
        }

        if ($this->isFake()) {
            $data = ['status' => 'success', 'amount' => $payment->amount_kobo, 'currency' => 'NGN', 'channel' => 'fake', 'paid_at' => now()->toIso8601String()];
        } else {
            try {
                $response = $this->client()->get('/transaction/verify/'.rawurlencode($payment->reference));
                if ($response->failed()) {
                    $err = $response->json('message') ?? ('Paystack verification failed (HTTP '.$response->status().')');
                    throw new RuntimeException("Paystack error: {$err}");
                }
                $data = $response->json('data') ?? [];
            } catch (Throwable $e) {
                if ($e instanceof RuntimeException) {
                    throw $e;
                }
                throw new RuntimeException('Unable to reach Paystack to verify payment: '.$e->getMessage(), 0, $e);
            }
        }

        return $this->record($payment, $data);
    }

    /**
     * Refund a confirmed payment in full through Paystack.
     *
     * @return array{ok: bool, reference: ?string, message: string}
     */
    public function refund(Payment $payment): array
    {
        if ($this->isFake() || $payment->channel === 'fake') {
            return ['ok' => true, 'reference' => 'TEST-REFUND-'.$payment->reference, 'message' => 'Test mode: refund simulated.'];
        }

        $response = $this->client()->post('/refund', ['transaction' => $payment->reference]);
        $data = $response->json('data') ?? [];

        return [
            'ok' => $response->successful() && (bool) $response->json('status'),
            'reference' => isset($data['id']) ? (string) $data['id'] : null,
            'message' => (string) ($response->json('message') ?? 'No response from Paystack.'),
        ];
    }

    /**
     * Handle a webhook. Returns false if the signature is invalid.
     */
    public function handleWebhook(string $rawBody, ?string $signature): bool
    {
        $secret = (string) config('nis.paystack.secret_key');
        if ($secret === '' || ! $signature || ! hash_equals(hash_hmac('sha512', $rawBody, $secret), $signature)) {
            return false;
        }

        $event = json_decode($rawBody, true);
        if (($event['event'] ?? null) === 'charge.success') {
            $payment = Payment::where('reference', $event['data']['reference'] ?? '')->first();
            // Never trust the webhook body alone: re-verify with the API.
            if ($payment) {
                $this->verify($payment);
            }
        }

        return true;
    }

    private function record(Payment $payment, array $data): Payment
    {
        return DB::transaction(function () use ($payment, $data) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->firstOrFail();
            if ($payment->isSuccessful()) {
                return $payment;
            }

            $ok = ($data['status'] ?? null) === 'success'
                && (int) ($data['amount'] ?? 0) === (int) $payment->amount_kobo
                && ($data['currency'] ?? null) === $payment->currency;

            $payment->fill([
                'status' => $ok ? 'SUCCESS' : 'FAILED',
                'channel' => $data['channel'] ?? null,
                'paid_at' => $ok ? ($data['paid_at'] ?? now()) : null,
                'verified_at' => $ok ? now() : null,
                'gateway_response' => $data,
            ])->save();

            Audit::log($ok ? 'PAYMENT_VERIFIED' : 'PAYMENT_FAILED', "Payment {$payment->reference}", $payment,
                ['amount_kobo' => $payment->amount_kobo, 'gateway_status' => $data['status'] ?? null]);

            return $payment;
        });
    }

    private function client()
    {
        $secret = config('nis.paystack.secret_key');
        if (! $secret) {
            throw new RuntimeException('PAYSTACK_SECRET_KEY is not configured in your server .env file.');
        }

        return Http::baseUrl(config('nis.paystack.base_url', 'https://api.paystack.co'))
            ->withToken($secret)
            ->acceptJson()
            ->timeout(20);
    }
}
