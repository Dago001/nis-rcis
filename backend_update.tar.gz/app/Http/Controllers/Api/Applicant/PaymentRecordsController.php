<?php

namespace App\Http\Controllers\Api\Applicant;

use App\Models\Applicant;
use App\Models\Payment;
use App\Models\Refund;
use App\Services\PaymentGatewayManager;
use App\Services\RefundService;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * The applicant's payments: PDF receipts and refund requests.
 */
class PaymentRecordsController
{
    public function index(Request $request, RefundService $refunds): JsonResponse
    {
        $applicant = $this->applicant($request);
        $payments = Payment::with('application:id,application_number,reference_number,status')
            ->where('applicant_id', $applicant->id)
            ->latest('id')
            ->get();
        $requests = Refund::where('applicant_id', $applicant->id)->get()->keyBy('payment_id');

        return response()->json(['data' => $payments->map(fn (Payment $p) => [
            'reference' => $p->reference,
            'amount_naira' => $p->amount_kobo / 100,
            'status' => $p->status,
            'paid_at' => $p->paid_at?->toIso8601String() ?? $p->created_at?->toIso8601String(),
            'application' => $p->application ? [
                'id' => $p->application->id,
                'application_number' => $p->application->application_number,
                'reference_number' => $p->application->reference_number,
                'status' => $p->application->status->value,
            ] : null,
            'refundable' => $refunds->eligible($p),
            'refund' => ($r = $requests->get($p->id)) ? ['status' => $r->status, 'reason' => $r->reason, 'decision_notes' => $r->decision_notes, 'requested_at' => $r->created_at?->toIso8601String()] : null,
        ])]);
    }

    public function receipt(Request $request, string $reference): Response
    {
        $applicant = $this->applicant($request);
        $payment = Payment::with(['application.enrollmentCenter'])
            ->where('reference', $reference)
            ->where('applicant_id', $applicant->id)
            ->whereIn('status', ['SUCCESS', 'REFUNDED'])
            ->firstOrFail();

        $logoPath = public_path('images/nis-logo.png');
        $logoData = file_exists($logoPath)
            ? 'data:image/png;base64,'.base64_encode((string) file_get_contents($logoPath))
            : '';

        $html = view('pdf.receipt', [
            'payment' => $payment,
            'applicant' => $applicant,
            'application' => $payment->application,
            'receipt' => PaymentGatewayManager::receipt($payment),
            'logo' => $logoData,
        ])->render();

        try {
            $options = new Options;
            $options->setChroot(public_path());
            $options->setIsRemoteEnabled(true);
            $pdf = new Dompdf($options);
            $pdf->loadHtml($html);
            $pdf->setPaper('A4');
            $pdf->render();

            return response($pdf->output(), 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="NIS-receipt-'.$payment->reference.'.pdf"',
            ]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('DOMPDF receipt rendering fallback: '.$e->getMessage());

            return response($html, 200, [
                'Content-Type' => 'text/html; charset=UTF-8',
            ]);
        }
    }

    public function requestRefund(Request $request, RefundService $refunds): JsonResponse
    {
        $data = $request->validate([
            'payment_reference' => ['required', 'string', 'max:64'],
            'reason' => ['required', 'string', 'min:10', 'max:1000'],
        ]);
        $applicant = $this->applicant($request);
        $payment = Payment::where('reference', $data['payment_reference'])->where('applicant_id', $applicant->id)->firstOrFail();
        $refund = $refunds->request($applicant, $payment, $data['reason']);

        return response()->json(['message' => 'Refund requested. You will be told the decision by e-mail.', 'status' => $refund->status], 201);
    }

    private function applicant(Request $request): Applicant
    {
        return $request->user();
    }
}
