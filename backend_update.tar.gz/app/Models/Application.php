<?php

namespace App\Models;

use App\Enums\ApplicationStatus;
use App\Enums\DocumentType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Application extends Model
{
    use HasFactory;

    /** Particulars shared with ResidenceCard (copied onto the card at capture). */
    public const PARTICULARS = [
        'surname', 'forenames', 'nationality', 'date_of_birth', 'place_of_birth', 'sex', 'height',
        'complexion', 'eye_color', 'hair_color', 'distinguished_features', 'blood_group', 'profession',
        'home_country', 'home_country_state', 'home_country_city', 'home_country_district', 'home_country_address', 'home_country_postal_code',
        'domicile', 'domicile_state', 'domicile_lga', 'change_of_address', 'passport_number', 'passport_issue_date', 'passport_expiry',
        'national_id_number', 'tax_id_number', 'emergency_contact_name', 'emergency_contact_relation',
        'emergency_contact_phone', 'emergency_contact_address', 'emergency_contact_state', 'emergency_contact_lga',
        'emergency_contact_id_type',
        'home_country_emergency_contact_name', 'home_country_emergency_contact_relation',
        'home_country_emergency_contact_phone',
        'home_country_emergency_contact_country', 'home_country_emergency_contact_state', 'home_country_emergency_contact_city', 'home_country_emergency_contact_district', 'home_country_emergency_contact_address', 'home_country_emergency_contact_postal_code',
        'home_country_emergency_contact_id_type',
    ];

    protected $guarded = ['id', 'status', 'application_number', 'reference_number'];

    protected $hidden = ['fingerprint_template', 'fingerprints', 'risk_flags'];

    protected static function booted(): void
    {
        static::addGlobalScope(new \App\Models\Scopes\RowLevelSecurityScope);
    }

    protected function casts(): array
    {
        return [
            'status' => ApplicationStatus::class,
            'date_of_birth' => 'date:Y-m-d',
            'passport_issue_date' => 'date:Y-m-d',
            'passport_expiry' => 'date:Y-m-d',
            'appointment_date' => 'date:Y-m-d',
            'submitted_at' => 'datetime',
            'vetted_at' => 'datetime',
            'decided_at' => 'datetime',
            'biometrics_captured_at' => 'datetime',
            'ready_at' => 'datetime',
            'collected_at' => 'datetime',
            'risk_flags' => 'array',
            'fingerprints' => 'encrypted:array',
            'risk_checked_at' => 'datetime',
            'has_cod' => 'boolean',
            'cod_changes' => 'array',
            'cod_fee_kobo' => 'integer',
        ];
    }

    public function fromEncryptedString($value)
    {
        try {
            return parent::fromEncryptedString($value);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            \Illuminate\Support\Facades\Log::warning("Corrupted encrypted attribute on application {$this->id}: {$e->getMessage()}");
            return null;
        }
    }

    public function applicant(): BelongsTo
    {
        return $this->belongsTo(Applicant::class);
    }

    public function enrollmentCenter(): BelongsTo
    {
        return $this->belongsTo(EnrollmentCenter::class);
    }

    public function actualEnrollmentCenter(): BelongsTo
    {
        return $this->belongsTo(EnrollmentCenter::class, 'actual_enrollment_center_id');
    }

    public function command(): BelongsTo
    {
        return $this->belongsTo(NisCommand::class, 'command_id');
    }

    public function getResponsibleCommandAttribute(): ?NisCommand
    {
        return $this->command ?? $this->enrollmentCenter?->nisCommand ?? $this->actualEnrollmentCenter?->nisCommand;
    }

    public function card(): BelongsTo
    {
        return $this->belongsTo(ResidenceCard::class, 'card_id');
    }

    public function cardDistribution(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(CardDistribution::class, 'application_id');
    }

    public function scopeForStaffJurisdiction(\Illuminate\Database\Eloquent\Builder $query, ?User $user): \Illuminate\Database\Eloquent\Builder
    {
        if (! $user || $user->isHeadquarters()) {
            return $query;
        }

        if ($user->isZonal()) {
            return $query->where(function ($q) use ($user) {
                $q->whereHas('enrollmentCenter', fn ($cq) => $cq->where('zone_id', $user->zone_id))
                  ->orWhereHas('actualEnrollmentCenter', fn ($cq) => $cq->where('zone_id', $user->zone_id))
                  ->orWhereHas('command', fn ($cq) => $cq->where('zone_id', $user->zone_id))
                  ->orWhereHas('cardDistribution', fn ($dq) => $dq->where('destination_zone_id', $user->zone_id));
                if ($user->zone) {
                    $q->orWhere('actual_enrollment_zone', $user->zone->name)
                      ->orWhere('actual_enrollment_zone', $user->zone->code);
                }
            });
        }

        if ($user->isCommand()) {
            $cmdId = $user->getEffectiveCommandId();
            return $query->where(function ($q) use ($user, $cmdId) {
                if ($cmdId) {
                    $q->where('command_id', $cmdId)
                      ->orWhereHas('enrollmentCenter', fn ($cq) => $cq->where('command_id', $cmdId))
                      ->orWhereHas('actualEnrollmentCenter', fn ($cq) => $cq->where('command_id', $cmdId))
                      ->orWhereHas('cardDistribution', fn ($dq) => $dq->where('destination_command_id', $cmdId));
                }
                if ($user->nisCommand) {
                    $q->orWhere('actual_enrollment_command', $user->nisCommand->name)
                      ->orWhere('actual_enrollment_command', $user->nisCommand->code);
                } elseif (! empty($user->command)) {
                    $q->orWhere('actual_enrollment_command', $user->command);
                }
            });
        }

        if ($user->state) {
            return $query->where(function ($q) use ($user) {
                $q->whereHas('enrollmentCenter', fn ($cq) => $cq->where('state', $user->state))
                  ->orWhere('domicile_state', $user->state);
            });
        }

        return $query;
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    /** The account holder's own application, when this one is for a spouse or child. */
    public function principal(): BelongsTo
    {
        return $this->belongsTo(Application::class, 'principal_application_id');
    }

    public function dependants(): HasMany
    {
        return $this->hasMany(Application::class, 'principal_application_id');
    }

    public function renewalOfCard(): BelongsTo
    {
        return $this->belongsTo(ResidenceCard::class, 'renewal_of_card_id');
    }

    public function decidedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'decided_by');
    }

    public function vettedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'vetted_by');
    }

    public function biometricsCapturedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'biometrics_captured_by');
    }

    public function documents(): HasMany
    {
        return $this->hasMany(ApplicationDocument::class)->where('is_current', true);
    }

    public function allDocuments(): HasMany
    {
        return $this->hasMany(ApplicationDocument::class);
    }

    public function documentQueries(): HasMany
    {
        return $this->hasMany(ApplicationDocumentQuery::class);
    }

    public function unresolvedDocumentQueries(): HasMany
    {
        return $this->hasMany(ApplicationDocumentQuery::class)
            ->where('status', '!=', ApplicationDocumentQuery::STATUS_RESOLVED);
    }

    public function statusHistory(): HasMany
    {
        return $this->hasMany(ApplicationStatusHistory::class)->orderBy('id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function currentDocument(DocumentType $type): ?ApplicationDocument
    {
        return $this->documents->firstWhere('type', $type);
    }

    public function fullName(): string
    {
        return trim("{$this->forenames} {$this->surname}");
    }

    public function getCategoryAttribute(?string $value): ?string
    {
        if (! empty($value)) {
            return strtoupper($value);
        }

        // Infer from documents if column is empty on older records
        if ($this->relationLoaded('documents')) {
            $docs = $this->documents;
            if ($docs->contains('type', DocumentType::AdmissionLetter) || $docs->contains('type', DocumentType::AcceptanceLetter) || $docs->contains('type', DocumentType::ProofOfPayment)) {
                return 'STUDENT';
            }
            if ($docs->contains('type', DocumentType::CacCertificate)) {
                return 'BUSINESS';
            }
            if ($docs->contains('type', DocumentType::AppointmentLetter)) {
                return 'WORK';
            }
            if ($docs->contains('type', DocumentType::ReligiousInvitation) || $docs->contains('type', DocumentType::ReligiousRegistration)) {
                return 'RELIGIOUS';
            }
        }

        return null;
    }

    public function getVettingStatusAttribute(): string
    {
        if ($this->vetted_at !== null || in_array($this->status, [
            ApplicationStatus::Vetted,
            ApplicationStatus::BiometricsCaptured,
            ApplicationStatus::Approved,
            ApplicationStatus::ApprovedForBiometrics,
            ApplicationStatus::ReadyForCollection,
            ApplicationStatus::Issued,
        ], true)) {
            return 'VETTED';
        }

        if ($this->status === ApplicationStatus::Queried && $this->vetted_at === null) {
            return 'QUERIED';
        }

        if ($this->status === ApplicationStatus::Rejected && $this->vetted_at === null) {
            return 'REJECTED';
        }

        return 'PENDING_APPROVAL';
    }

    public function getVettingStatusLabelAttribute(): string
    {
        return match ($this->vetting_status) {
            'VETTED' => 'Vetted',
            'QUERIED' => 'Queried',
            'REJECTED' => 'Rejected',
            default => 'Awaiting Vetting',
        };
    }

    public function getBiometricsStatusAttribute(): string
    {
        if ($this->biometrics_captured_at !== null || in_array($this->status, [
            ApplicationStatus::BiometricsCaptured,
            ApplicationStatus::Approved,
            ApplicationStatus::ApprovedForBiometrics,
            ApplicationStatus::ReadyForCollection,
            ApplicationStatus::Issued,
        ], true)) {
            return 'COMPLETED';
        }

        if ($this->vetted_at !== null || $this->status === ApplicationStatus::Vetted) {
            return 'ELIGIBLE';
        }

        return 'PENDING_VETTING';
    }

    public function getBiometricsStatusLabelAttribute(): string
    {
        return match ($this->biometrics_status) {
            'COMPLETED' => 'Completed',
            'ELIGIBLE' => 'Eligible — Awaiting Attendance',
            default => 'Pending Vetting',
        };
    }

    public function getApprovalStatusAttribute(): ?string
    {
        if (in_array($this->status, [
            ApplicationStatus::Approved,
            ApplicationStatus::ApprovedForBiometrics,
            ApplicationStatus::ReadyForCollection,
            ApplicationStatus::Issued,
        ], true) || ($this->decided_at !== null && ! in_array($this->status, [ApplicationStatus::Queried, ApplicationStatus::Rejected], true))) {
            return 'APPROVED';
        }

        if ($this->status === ApplicationStatus::Queried && $this->biometrics_captured_at !== null) {
            return 'QUERIED';
        }

        if ($this->status === ApplicationStatus::Rejected && $this->decided_at !== null) {
            return 'REJECTED';
        }

        if ($this->status === ApplicationStatus::BiometricsCaptured || ($this->biometrics_captured_at !== null && $this->decided_at === null)) {
            return 'AWAITING_APPROVAL';
        }

        if ($this->status === ApplicationStatus::Vetted || $this->vetted_at !== null) {
            return 'AWAITING_BIOMETRICS';
        }

        return null;
    }

    public function getApprovalStatusLabelAttribute(): ?string
    {
        return match ($this->approval_status) {
            'APPROVED' => 'Approved',
            'AWAITING_APPROVAL' => 'Awaiting Approval',
            'AWAITING_BIOMETRICS' => 'Awaiting Biometrics',
            'QUERIED' => 'Queried',
            'REJECTED' => 'Rejected',
            default => null,
        };
    }
}
