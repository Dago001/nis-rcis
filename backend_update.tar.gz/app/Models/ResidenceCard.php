<?php

namespace App\Models;

use App\Enums\CardStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ResidenceCard extends Model
{
    use HasFactory;

    protected $guarded = ['id', 'status', 'card_number', 'verification_token'];

    protected $hidden = ['verification_token'];

    protected static function booted(): void
    {
        static::addGlobalScope(new \App\Models\Scopes\RowLevelSecurityScope);
    }

    protected function casts(): array
    {
        return [
            'status' => CardStatus::class,
            'date_of_birth' => 'date:Y-m-d',
            'passport_issue_date' => 'date:Y-m-d',
            'passport_expiry' => 'date:Y-m-d',
            'decision_date' => 'date:Y-m-d',
            'issued_on' => 'date:Y-m-d',
            'expires_on' => 'date:Y-m-d',
            'is_watchlisted' => 'boolean',
            'revoked_at' => 'datetime',
            'watchlisted_at' => 'datetime',
            'approved_at' => 'datetime',
            'reported_lost_at' => 'datetime',
        ];
    }

    public function isExpired(): bool
    {
        return $this->expires_on !== null && $this->expires_on->isPast() && ! $this->expires_on->isToday();
    }

    /**
     * Status shown to the public / partner verifiers.
     * VALID | EXPIRED | REVOKED | REPORTED_LOST | REPORTED_STOLEN | WATCHLISTED | NOT_ISSUED
     */
    public function verificationStatus(): string
    {
        return match (true) {
            $this->status === CardStatus::Revoked => 'REVOKED',
            $this->reported_lost_at !== null => 'REPORTED_'.($this->lost_report_type ?: 'LOST'),
            $this->is_watchlisted => 'WATCHLISTED',
            ! $this->status->isActive() => 'NOT_ISSUED',
            $this->isExpired() => 'EXPIRED',
            default => 'VALID',
        };
    }

    public function printJobs(): HasMany
    {
        return $this->hasMany(CardPrintJob::class, 'card_id');
    }

    public function lostCardReports(): HasMany
    {
        return $this->hasMany(LostCardReport::class, 'card_id');
    }

    public function renewals(): HasMany
    {
        return $this->hasMany(CardRenewal::class, 'card_id')->orderBy('renewal_number');
    }

    public function application(): HasOne
    {
        return $this->hasOne(Application::class, 'card_id');
    }

    public function distribution(): HasOne
    {
        return $this->hasOne(CardDistribution::class, 'card_id');
    }

    public function scopeForStaffJurisdiction(\Illuminate\Database\Eloquent\Builder $query, ?User $user): \Illuminate\Database\Eloquent\Builder
    {
        if (! $user || $user->isHeadquarters()) {
            return $query;
        }

        if ($user->isZonal()) {
            return $query->where(function ($q) use ($user) {
                $q->whereHas('application.enrollmentCenter', fn ($cq) => $cq->where('zone_id', $user->zone_id))
                  ->orWhereHas('actualEnrollmentCenter', fn ($cq) => $cq->where('zone_id', $user->zone_id))
                  ->orWhereHas('distribution', fn ($dq) => $dq->where('destination_zone_id', $user->zone_id));
                if ($user->zone) {
                    $q->orWhere('enrollment_zone', $user->zone->name);
                }
            });
        }

        if ($user->isCommand()) {
            $cmdId = $user->getEffectiveCommandId();
            return $query->where(function ($q) use ($user, $cmdId) {
                if ($cmdId) {
                    $q->whereHas('application', fn ($aq) => $aq->where('command_id', $cmdId))
                      ->orWhereHas('application.enrollmentCenter', fn ($cq) => $cq->where('command_id', $cmdId))
                      ->orWhereHas('actualEnrollmentCenter', fn ($cq) => $cq->where('command_id', $cmdId))
                      ->orWhereHas('distribution', fn ($dq) => $dq->where('destination_command_id', $cmdId));
                }
                if ($user->nisCommand) {
                    $q->orWhere('enrollment_command', $user->nisCommand->name);
                }
            });
        }

        return $query;
    }

    public function actualEnrollmentCenter(): BelongsTo
    {
        return $this->belongsTo(EnrollmentCenter::class, 'actual_enrollment_center_id');
    }

    public function applicant(): BelongsTo
    {
        return $this->belongsTo(Applicant::class);
    }

    public function issuingOfficer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'issuing_officer_id');
    }

    public function fullName(): string
    {
        return trim("{$this->forenames} {$this->surname}");
    }
}
