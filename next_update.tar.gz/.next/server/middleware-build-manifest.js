globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Gwpwbj6y_vq_auka7cDOd/_buildManifest.js",
    "static/Gwpwbj6y_vq_auka7cDOd/_ssgManifest.js",
    "static/Gwpwbj6y_vq_auka7cDOd/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/3jg84jwj6s1uj.js",
    "static/chunks/turbopack-1h9hnkswx55yj.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
