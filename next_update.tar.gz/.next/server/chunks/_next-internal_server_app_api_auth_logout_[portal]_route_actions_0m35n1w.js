module.exports=[66154,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_logout_%5Bportal%5D_route_actions_0m35n1w.js.map