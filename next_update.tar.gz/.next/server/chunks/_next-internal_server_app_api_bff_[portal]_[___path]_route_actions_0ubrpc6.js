module.exports=[95524,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bff_%5Bportal%5D_%5B___path%5D_route_actions_0ubrpc6.js.map