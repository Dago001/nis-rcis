module.exports=[16262,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_queue_page_actions_0l-sy_8.js.map