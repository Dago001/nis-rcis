module.exports=[60010,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28auth%29_reset-password_page_actions_0j71bks.js.map