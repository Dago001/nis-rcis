module.exports=[82747,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_reports_page_actions_1tg1-mv.js.map