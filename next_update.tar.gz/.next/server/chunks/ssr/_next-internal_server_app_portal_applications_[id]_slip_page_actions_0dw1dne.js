module.exports=[5736,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_applications_%5Bid%5D_slip_page_actions_0dw1dne.js.map