module.exports=[85321,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28auth%29_forgot-password_page_actions_1rf482f.js.map