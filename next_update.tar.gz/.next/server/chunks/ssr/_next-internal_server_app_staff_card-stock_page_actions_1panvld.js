module.exports=[49942,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_card-stock_page_actions_1panvld.js.map