module.exports=[37806,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28auth%29_auth-error_page_actions_1c6339u.js.map