module.exports=[87248,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_approvals_%5Bid%5D_page_actions_0kw73e9.js.map