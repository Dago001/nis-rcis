module.exports=[93023,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28pages%29_track_page_actions_1q4svyk.js.map