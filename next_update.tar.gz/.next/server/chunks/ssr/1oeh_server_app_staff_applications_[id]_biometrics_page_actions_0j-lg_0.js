module.exports=[77651,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_staff_applications_%5Bid%5D_biometrics_page_actions_0j-lg_0.js.map