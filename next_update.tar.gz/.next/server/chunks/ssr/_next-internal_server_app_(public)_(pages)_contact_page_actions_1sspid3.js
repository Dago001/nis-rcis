module.exports=[63832,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28pages%29_contact_page_actions_1sspid3.js.map