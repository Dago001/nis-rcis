module.exports=[60059,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28pages%29_about_page_actions_122-k8t.js.map