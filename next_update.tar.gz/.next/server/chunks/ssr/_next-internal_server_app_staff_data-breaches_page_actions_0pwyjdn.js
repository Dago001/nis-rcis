module.exports=[51644,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_data-breaches_page_actions_0pwyjdn.js.map