module.exports=[35930,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28auth%29_login_page_actions_1jmre8k.js.map