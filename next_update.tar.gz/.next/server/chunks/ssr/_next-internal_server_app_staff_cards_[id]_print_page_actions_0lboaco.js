module.exports=[22071,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_cards_%5Bid%5D_print_page_actions_0lboaco.js.map