module.exports=[88108,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_queue-display_%5Bcenter%5D_page_actions_1iy-i8d.js.map