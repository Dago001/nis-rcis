module.exports=[23026,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_approvals_page_actions_12v-8jl.js.map