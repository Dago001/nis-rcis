module.exports=[88965,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_notifications_page_actions_09lo1w8.js.map