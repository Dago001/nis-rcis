module.exports=[27657,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_applications_%5Bid%5D_page_actions_0q-8jgk.js.map