module.exports=[6451,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_applications_page_actions_1my6_4x.js.map