module.exports=[62583,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_system_page_actions_17gm4ka.js.map