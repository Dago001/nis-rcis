module.exports=[29947,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_audit-logs_page_actions_09v394i.js.map