module.exports=[98231,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28pages%29_faq_page_actions_1xrndmd.js.map