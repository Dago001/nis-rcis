module.exports=[38697,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staff_applications_new_page_actions_03ruyue.js.map