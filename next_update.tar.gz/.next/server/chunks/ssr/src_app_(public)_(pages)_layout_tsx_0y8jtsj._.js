module.exports=[22751,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("main",{id:"main",tabIndex:-1,className:"mx-auto w-full max-w-6xl flex-1 px-4 py-12",children:a})}])},49876,function(a){a.n(a.i(22751))}];

//# sourceMappingURL=src_app_%28public%29_%28pages%29_layout_tsx_0y8jtsj._.js.map