module.exports=[35999,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28auth%29_register_page_actions_0l_tzuk.js.map