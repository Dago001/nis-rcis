module.exports=[81774,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_applications_%5Bid%5D_page_actions_1tpek6b.js.map