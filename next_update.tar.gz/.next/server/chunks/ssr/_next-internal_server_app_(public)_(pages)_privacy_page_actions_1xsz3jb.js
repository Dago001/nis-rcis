module.exports=[90559,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_%28pages%29_privacy_page_actions_1xsz3jb.js.map