var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public-account/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__0-twbzx._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_public-account_[___path]_route_actions_0rt3ax8.js")
R.m(19601)
module.exports=R.m(19601).exports
