var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/[portal]/route.js")
R.c("server/chunks/[root-of-the-server]__1fqqvt6._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_[portal]_route_actions_10fojy-.js")
R.m(58467)
module.exports=R.m(58467).exports
