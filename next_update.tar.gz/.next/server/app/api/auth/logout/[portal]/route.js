var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/[portal]/route.js")
R.c("server/chunks/[root-of-the-server]__18wfkjk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_[portal]_route_actions_0m35n1w.js")
R.m(99620)
module.exports=R.m(99620).exports
