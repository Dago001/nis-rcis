var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/callback/[portal]/route.js")
R.c("server/chunks/[root-of-the-server]__0q3v4g0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_callback_[portal]_route_actions_1kkd8ct.js")
R.m(63713)
module.exports=R.m(63713).exports
