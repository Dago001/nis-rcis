var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/turnstile-key/route.js")
R.c("server/chunks/[root-of-the-server]__0f1c6f2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_turnstile-key_route_actions_1-b6agx.js")
R.m(21321)
module.exports=R.m(21321).exports
