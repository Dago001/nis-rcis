var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bff/[portal]/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1ienljm._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0jnd4o7._.js")
R.c("server/chunks/_next-internal_server_app_api_bff_[portal]_[___path]_route_actions_0ubrpc6.js")
R.m(65977)
module.exports=R.m(65977).exports
