var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__0ufgsk9._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0lz3t4l._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_08hcpz0.js")
R.m(22945)
module.exports=R.m(22945).exports
