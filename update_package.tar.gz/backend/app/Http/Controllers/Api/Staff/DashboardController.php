<?php

namespace App\Http\Controllers\Api\Staff;

use App\Enums\ApplicationStatus;
use App\Enums\CardStatus;
use App\Models\Application;
use App\Models\ApplicationStatusHistory;
use App\Models\Payment;
use App\Models\QueueTicket;
use App\Models\ResidenceCard;
use App\Models\User;
use App\Services\CardProduction;
use App\Support\WorkingDays;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController
{
    public function me(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        return response()->json([
            'id' => $user->id,
            'username' => $user->username,
            'fullname' => $user->fullname,
            'service_number' => $user->service_number,
            'email' => $user->email,
            'role' => $user->role->value,
            'role_label' => $user->role->label(),
            'command' => $user->command,
            'state' => $user->getAttributes()['state'] ?? null,
            'lga' => $user->getAttributes()['lga'] ?? null,
            'unread_notifications' => $user->unreadNotifications()->count(),
        ]);
    }

    public function summary(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $data = \Illuminate\Support\Facades\Cache::remember("staff_summary_{$user->id}", 15, function () use ($user) {
            $applications = Application::query()->selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status');
            $cards = ResidenceCard::query()->selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status');

            return [
                'queue' => collect(ApplicationStatus::cases())->mapWithKeys(fn ($s) => [$s->value => (int) ($applications[$s->value] ?? 0)]),
                'cards' => collect(CardStatus::cases())->mapWithKeys(fn ($s) => [$s->value => (int) ($cards[$s->value] ?? 0)]),
                'cards_expired' => ResidenceCard::whereIn('status', [CardStatus::Issued, CardStatus::Renewed])->where('expires_on', '<', today())->count(),
                'cards_expiring_30_days' => ResidenceCard::whereIn('status', [CardStatus::Issued, CardStatus::Renewed])->whereBetween('expires_on', [today(), today()->addDays(30)])->count(),
                'watchlisted' => ResidenceCard::where('is_watchlisted', true)->count(),
                'paid_awaiting_submission' => Payment::where('status', 'SUCCESS')->whereNotNull('verified_at')->whereNull('application_id')->count(),
                'sla' => [
                    'target_working_days' => (int) config('nis.sla_working_days'),
                    'overdue' => Application::where('status', ApplicationStatus::PendingApproval)
                        ->where('submitted_at', '<', WorkingDays::cutoff(config('nis.sla_working_days')))->count(),
                    'assigned_to_me' => Application::where('assigned_to', $user->id)
                        ->whereNotIn('status', [ApplicationStatus::Rejected, ApplicationStatus::Issued])->count(),
                ],
                'card_stock' => app(CardProduction::class)->stock(),
                'queue_today' => QueueTicket::whereDate('service_date', today())->selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status')->map(fn ($v) => (int) $v),
                'todays_appointments' => Application::where('status', ApplicationStatus::ApprovedForBiometrics)->whereDate('appointment_date', today())->count(),
                'analytics' => $this->analytics(),
                'my_activity' => [
                    'decided' => Application::where('decided_by', $user->id)->count(),
                    'captured' => Application::where('biometrics_captured_by', $user->id)->count(),
                    'cards_approved' => ResidenceCard::where('approved_by', $user->id)->count(),
                    'assisted_created' => Application::where('created_by', $user->id)->count(),
                    'cards_printed' => \App\Models\CardPrintJob::where('printed_by', $user->id)->where('outcome', 'PRINTED')->count(),
                    'cards_collected' => Application::where('status', ApplicationStatus::Issued)->whereNotNull('collected_at')->count(),
                ],
            ];
        });

        return response()->json($data);
    }

    /**
     * Aggregates for the dashboard charts. Counts and sums only: no personal
     * data leaves this method.
     */
    private function analytics(): array
    {
        $start = CarbonImmutable::now()->startOfMonth()->subMonths(11);
        $months = collect(range(0, 11))->map(fn ($i) => $start->addMonths($i)->format('Y-m'));

        try {
            $driver = \Illuminate\Support\Facades\DB::connection()->getDriverName();

            $monthFormat = match ($driver) {
                'mysql' => "DATE_FORMAT({column}, '%Y-%m')",
                'sqlite' => "strftime('%Y-%m', {column})",
                default => "to_char(date_trunc('month', {column}), 'YYYY-MM')",
            };

            $perMonth = fn ($query, string $column, string $aggregate = 'count(*)') => $query
                ->where($column, '>=', $start)
                ->selectRaw(str_replace('{column}', $column, $monthFormat) . " as month, {$aggregate} as total")
                ->groupBy('month')
                ->pluck('total', 'month');

            $submitted = $perMonth(Application::query(), 'submitted_at');
            $issued = $perMonth(ResidenceCard::query()->whereNotNull('issued_on'), 'issued_on');
            $revenue = $perMonth(Payment::query()->where('status', 'SUCCESS')->whereNotNull('verified_at'), 'paid_at', 'sum(amount_kobo)');

            $decisions = ApplicationStatusHistory::query()
                ->whereIn('to_status', [ApplicationStatus::ApprovedForBiometrics->value, ApplicationStatus::Queried->value, ApplicationStatus::Rejected->value])
                ->selectRaw('to_status, count(*) as total')->groupBy('to_status')->pluck('total', 'to_status');
            $approved = (int) ($decisions[ApplicationStatus::ApprovedForBiometrics->value] ?? 0);
            $queried = (int) ($decisions[ApplicationStatus::Queried->value] ?? 0);
            $rejected = (int) ($decisions[ApplicationStatus::Rejected->value] ?? 0);

            $avgDays = function (string $from, string $to) use ($driver) {
                $expr = match ($driver) {
                    'mysql' => "avg(TIMESTAMPDIFF(SECOND, {$from}, {$to}) / 86400)",
                    'sqlite' => "avg(julianday({$to}) - julianday({$from}))",
                    default => "avg(extract(epoch from ({$to} - {$from})) / 86400)",
                };
                return round((float) Application::query()
                    ->whereNotNull($from)->whereNotNull($to)
                    ->selectRaw("{$expr} as days")
                    ->value('days'), 1);
            };

            $split = fn (string $column) => Application::query()
                ->selectRaw("{$column} as label, count(*) as total")->groupBy($column)->orderByDesc('total')
                ->pluck('total', 'label')->map(fn ($v) => (int) $v);

            $paid = Payment::query()->where('status', 'SUCCESS')->whereNotNull('verified_at');

            $dayFormat = match ($driver) {
                'mysql' => "DATE_FORMAT(appointment_date, '%Y-%m-%d')",
                'sqlite' => "strftime('%Y-%m-%d', appointment_date)",
                default => "to_char(appointment_date, 'YYYY-MM-DD')",
            };

            $appointments = Application::query()
                ->whereIn('status', [ApplicationStatus::PendingApproval, ApplicationStatus::ApprovedForBiometrics])
                ->whereBetween('appointment_date', [today(), today()->addDays(20)])
                ->selectRaw("{$dayFormat} as day, count(*) as total")
                ->groupBy('day')->pluck('total', 'day');
            $days = collect(range(0, 20))->map(fn ($i) => CarbonImmutable::today()->addDays($i))
                ->reject(fn ($d) => $d->isWeekend())->take(10)->values();

            return [
                'monthly' => $months->map(fn ($m) => [
                    'month' => $m,
                    'submitted' => (int) ($submitted[$m] ?? 0),
                    'issued' => (int) ($issued[$m] ?? 0),
                    'revenue_naira' => (int) ($revenue[$m] ?? 0) / 100,
                ])->values(),
                'totals' => [
                    'applications' => Application::count(),
                    'applications_this_month' => (int) ($submitted[$months->last()] ?? 0),
                    'applications_last_month' => (int) ($submitted[$months[10]] ?? 0),
                    'cards_issued' => ResidenceCard::whereNotNull('issued_on')->count(),
                    'revenue_naira' => (int) (clone $paid)->sum('amount_kobo') / 100,
                    'revenue_this_month_naira' => (int) ($revenue[$months->last()] ?? 0) / 100,
                    'payments' => (clone $paid)->count(),
                ],
                'decisions' => [
                    'approved' => $approved,
                    'queried' => $queried,
                    'rejected' => $rejected,
                    'approval_rate' => $approved + $rejected > 0 ? round($approved / ($approved + $rejected) * 100) : null,
                ],
                'processing_days' => [
                    'submission_to_decision' => $avgDays('submitted_at', 'decided_at'),
                    'decision_to_biometrics' => $avgDays('decided_at', 'biometrics_captured_at'),
                    'biometrics_to_ready' => $avgDays('biometrics_captured_at', 'ready_at'),
                    'ready_to_collection' => $avgDays('ready_at', 'collected_at'),
                ],
                'nationalities' => Application::query()->selectRaw('nationality, count(*) as total')
                    ->groupBy('nationality')->orderByDesc('total')->orderBy('nationality')->limit(8)->get()
                    ->map(fn ($r) => ['label' => $r->nationality, 'total' => (int) $r->total]),
                'mix' => [
                    'type' => $split('type'),
                    'channel' => $split('channel'),
                    'sex' => $split('sex'),
                ],
                'appointments' => $days->map(fn ($d) => ['date' => $d->toDateString(), 'total' => (int) ($appointments[$d->toDateString()] ?? 0)]),
            ];
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Dashboard analytics fallback: ' . $e->getMessage());
            return [
                'monthly' => $months->map(fn ($m) => ['month' => $m, 'submitted' => 0, 'issued' => 0, 'revenue_naira' => 0])->values(),
                'totals' => [
                    'applications' => Application::count(),
                    'applications_this_month' => 0,
                    'applications_last_month' => 0,
                    'cards_issued' => 0,
                    'revenue_naira' => 0,
                    'revenue_this_month_naira' => 0,
                    'payments' => 0,
                ],
                'decisions' => ['approved' => 0, 'queried' => 0, 'rejected' => 0, 'approval_rate' => null],
                'processing_days' => ['submission_to_decision' => 0, 'decision_to_biometrics' => 0, 'biometrics_to_ready' => 0, 'ready_to_collection' => 0],
                'nationalities' => [],
                'mix' => ['type' => [], 'channel' => [], 'sex' => []],
                'appointments' => [],
            ];
        }
    }
}
