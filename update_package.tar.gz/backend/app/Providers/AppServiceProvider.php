<?php

namespace App\Providers;

use App\Assistant\ClaudeLanguageModel;
use App\Assistant\LanguageModel;
use App\Integrations\Drivers\InterpolSltdHttp;
use App\Integrations\Drivers\MoiQuotaHttp;
use App\Integrations\Drivers\NotConfigured;
use App\Integrations\Drivers\SimulatedQuota;
use App\Integrations\Drivers\SimulatedSltd;
use App\Integrations\PassportRegistry;
use App\Integrations\QuotaRegistry;
use App\Models\OAuthClient;
use App\OAuth\StrictScopeRepository;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Laravel\Passport\Bridge\ScopeRepository;
use Laravel\Passport\Passport;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $driver = function (string $service, string $http, string $simulated) {
            $config = config("nis.integrations.{$service}");

            return match (true) {
                $config['driver'] === 'http' && filled($config['url']) => new $http($config),
                // Simulated answers are never allowed on the live system.
                $config['driver'] === 'simulated' && ! $this->app->isProduction() => new $simulated,
                default => new NotConfigured,
            };
        };
        $this->app->bind(PassportRegistry::class, fn () => $driver('interpol_sltd', InterpolSltdHttp::class, SimulatedSltd::class));
        $this->app->bind(QuotaRegistry::class, fn () => $driver('moi_quota', MoiQuotaHttp::class, SimulatedQuota::class));
        // OAuth routes are registered explicitly in routes/web.php so the
        // authorize endpoint can pick the staff or applicant login guard.
        Passport::ignoreRoutes();

        $this->app->bind(ScopeRepository::class, StrictScopeRepository::class);
        $this->app->bind(LanguageModel::class, ClaudeLanguageModel::class);
    }

    public function boot(): void
    {
        Model::shouldBeStrict(! $this->app->isProduction());

        $appUrl = (string) config('app.url');

        if ($this->app->isProduction() || str_starts_with($appUrl, 'https://') || request()->isSecure() || request()->header('X-Forwarded-Proto') === 'https') {
            URL::forceScheme('https');
        }

        if (! empty($appUrl) && ! str_contains($appUrl, '127.0.0.1') && ! str_contains($appUrl, 'localhost')) {
            URL::forceRootUrl($appUrl);
            if (str_starts_with($appUrl, 'https://')) {
                URL::forceScheme('https');
            }
        }

        $this->configureOAuth();
        $this->configureRateLimiting();
    }

    private function configureOAuth(): void
    {
        Passport::useClientModel(OAuthClient::class);
        Passport::tokensCan(config('nis.scopes'));

        // Short-lived access tokens; the Next.js BFF refreshes silently.
        Passport::tokensExpireIn(now()->addMinutes(15));
        Passport::refreshTokensExpireIn(now()->addHours(12));
        Passport::clientCredentialsTokensExpireIn(now()->addMinutes(30));

        // Consent screen for third-party authorization-code clients.
        // Our own first-party portals skip it (OAuthClient::skipsAuthorization).
        Passport::authorizationView('oauth.authorize');
    }

    private function configureRateLimiting(): void
    {
        RateLimiter::for('api', function (Request $request) {
            $userKey = $request->user()?->getAuthIdentifier()
                ?? $request->session()->get('applicant_id')
                ?? $request->session()->getId()
                ?? $request->ip();

            return Limit::perMinute(240)->by($userKey);
        });

        RateLimiter::for('uploads', function (Request $request) {
            $userKey = $request->user()?->getAuthIdentifier()
                ?? $request->session()->get('applicant_id')
                ?? $request->session()->getId()
                ?? $request->ip();

            return Limit::perMinute(60)->by('upload|'.$userKey);
        });

        RateLimiter::for('login', fn (Request $request) => [
            Limit::perMinute(5)->by(strtolower((string) $request->input('identifier')).'|'.$request->ip()),
            Limit::perMinute(20)->by($request->ip()),
        ]);

        // Authenticator codes: 5 tries a minute per pending sign-in.
        RateLimiter::for('two-factor', fn (Request $request) => Limit::perMinute(5)->by('2fa|'.($request->session()->get('staff_2fa')['id'] ?? $request->ip())));

        RateLimiter::for('oauth-token', fn (Request $request) => Limit::perMinute(30)->by($request->ip()));

        // Public, unauthenticated lookups (tracking, card verification)
        RateLimiter::for('public-lookup', fn (Request $request) => Limit::perMinute(10)->by($request->ip()));

        // Chat assistant: generous for people, useless for scripted abuse.
        RateLimiter::for('assistant', fn (Request $request) => [
            Limit::perMinute(12)->by('assistant-min|'.($request->user()?->getAuthIdentifier() ?? $request->ip())),
            Limit::perDay(300)->by('assistant-day|'.$request->ip()),
        ]);

        RateLimiter::for('registration', fn (Request $request) => Limit::perHour(10)->by($request->ip()));
    }
}
